# WUT?!

Nope, this is just not going to work with any version of bladerf software.

Install host tools ( libraries + utilities ), firmware.img and hostedx40.rbx from this folder.

## References

* [Discussion](http://forum.yate.ro/index.php?topic=372.0)
* [Firmware + FPGA](http://voip.null.ro/svn/yatebts/tags/RELEASE_5_0_0/mbts/TransceiverRAD1/)
* [Libraries](http://repo.yatebts.com/devel/bladeRF.tar.gz)
