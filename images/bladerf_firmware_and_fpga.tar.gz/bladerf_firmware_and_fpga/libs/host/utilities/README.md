# bladeRF Utilities #
This directory contains applications that utilize libbladeRF.

| Utility                   | Description                                                       |
| ------------------------- |:----------------------------------------------------------------- |
| [bladeRF-cli]             | Command line tool for development and debugging                   |
| [bladeRF-flash]           | Robust flashing utility                                           |

[bladeRF-cli]: ./bladeRF-cli (bladeRF-cli)
[bladeRF-flash]: ./bladeRF-flash (bladeRF-flash)
